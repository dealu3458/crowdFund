/**
 * banner数据
 */
function getBannerData() {
  var arr = ['../../images/banner_01.png', '../../images/banner_02.png', '../../images/banner_03.png', '../../images/banner_04.png']
  return arr
}
const item_var_data=[
  ' 大病救助' ,' 公益慈善', ' 心愿帮助', ' 地区建设'
]
/*
 * 首页 navnav 数据
 */
function getIndexNavData() {
  var arr = [
    {
      icon: "../../images/nav_icon_01.png",
      title: "推荐"
    },
    {
      icon: "../../images/nav_icon_02.png",
      title: "大病救助"
    },
    {
      icon: "../../images/nav_icon_03.png",
      title: "公益慈善"
    },
    {
      icon: "../../images/nav_icon_04.png",
      title: "心愿帮助"
    },
    {
      icon: "../../images/nav_icon_05.png",
      title: "地区建设"
    }
  ]
  return arr
}
/*
 * 首页 对应 标签 数据项
 */
function getIndexNavSectionData() {
  var arr = [
    [
      {

        subject: "我不想这么早秃头",
        coverpath: "../../images/recommend_img_01.png",
        price: '¥1000',
        message: '程序猿也想用海飞丝'
      },
      {

        subject: "我不想这么早秃头2",
        coverpath: "../../images/recommend_img_02.png",
        price: '¥1000',
        message: '程序猿也想用多芬'
      },
      {

        subject: "我不想这么早秃头3",
        coverpath: "../../images/recommend_img_03.png",
        price: '¥1000',
        message: '程序猿不想做光头强'
      },
      {

        subject: "我不想这么早秃头4",
        coverpath: "../../images/recommend_img_04.png",
        price: '¥1000',
        message: '程序猿也想用海飞丝'
      },
      {

        subject: "我不想这么早秃头5",
        coverpath: "../../images/recommend_img_05.png",
        price: '¥1000',
        message: '程序猿也想用海飞丝'
      }
    ],
    [
      {
        subject: "我不想这么早秃头",
        coverpath: "../../images/recommend_img_01.png",
        price: '¥1000',
        message: '程序猿也想用海飞丝'
      }
    ],
    [
      {
        subject: "我不想这么早秃头3",
        coverpath: "../../images/recommend_img_03.png",
        price: '¥1000',
        message: '程序猿也想用海飞丝'
      },
      {
        subject: "我不想这么早秃头5",
        coverpath: "../../images/recommend_img_05.png",
        price: '¥1000',
        message: '程序猿也想用海飞丝'
      }
    ],
    [

      {
        subject: "我不想这么早秃头4",
        coverpath: "../../images/recommend_img_04.png",
        price: '¥1000',
        message: '程序猿也想用海飞丝'
      }
    ],
    [
      {
        subject: "我不想这么早秃头2",
        coverpath: "../../images/recommend_img_02.png",
        price: '¥1000',
        message: '程序猿也想用海飞丝'
      }
    ]
  ]
  return arr
}



/**
 * 查询 地址
 * */
var user_data = userData()
function searchAddrFromAddrs(addrid) {
  var result
  for (let i = 0; i < user_data.addrs.length; i++) {
    var addr = user_data.addrs[i]
    console.log(addr)
    if (addr.addrid == addrid) {
      result = addr
    }
  }
  return result || {}
}
/**
 * 用户数据
 * */
function userData() {
  var arr = {
    uid: '1',
    nickname: '山炮',
    name: '张三',
    phone: '13833337998',
    avatar: '../../images/avatar.png',
    addrs: [
      {
        addrid: '1',
        name: '张三',
        phone: '13812314563',
        province: '北京',
        city: '直辖市',
        addr: '朝阳区望京悠乐汇A座8011'
      },
      {
        addrid: '2',
        name: '李四',
        phone: '13812314563',
        province: '北京',
        city: '直辖市',
        addr: '朝阳区望京悠乐汇A座4020'
      }
    ]
  }
  return arr
}
/**
 * 省
 * */
function provinceData() {
  var arr = [
    // {pid:1,pzip:'110000',pname:'北京市'},
    // {pid:2,pzip:'120000',pname:'天津市'}
    '请选择省份', '江苏省','浙江省','广东省','云南省'
  ]
  return arr
}
/**
 * 市
 * */
function cityData() {
  var arr = [
    // {cid:1,czip:'110100',cname:'市辖区',pzip:'110000'},
    // {cid:2,czip:'120100',cname:'市辖区',pzip:'120000'}
    '请选择城市', '南京市', '苏州市', '无锡市','常州市','镇江市','扬州市','泰州市','南通市','盐城市','淮安市','宿迁市','连云港市','南通市'
  ]
  return arr
}

/**
 * 项目类型
 * */
function tagData() {
  var arr = [
    // {tid:1,tzip:'110100',tname:'类型',pz:'110000'},
    // {tid:2,tzip:'120100',tname:'类型',pz:'120000'}
    '请选择项目类型', '大病救助', '公益慈善', 'TAG3','TAG4'
  ]
  return arr
}

/*
 * 对外暴露接口
 */
module.exports = {
  getBannerData: getBannerData,
  getIndexNavData: getIndexNavData,
  getIndexNavSectionData: getIndexNavSectionData,
//  getPickerData: getPickerData,
//  getSkilledData: getSkilledData,
  userData: userData,
  provinceData: provinceData,
  cityData: cityData,
  searchAddrFromAddrs: searchAddrFromAddrs,
  tagData:tagData,
  item_var_data: item_var_data
}