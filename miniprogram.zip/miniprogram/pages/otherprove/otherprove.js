const db=wx.cloud.database()
const testCollection=db.collection('test')
const _=db.command

Page({
  data: {
    array: ['亲人', '朋友', '邻居', '同事','老师','同学','病友','志愿者','参与者','其他'],
    index: 0,
    date: '2016-09-01',
    time: '12:01',
    info:null,
  },
  addDate:function(event){
    console.log(event)
    testCollection.add({
      data:{
        title:"Product 1",
        tags:["tag1","tag2"],
        price:128.12,
        color:'red'
      },
      success:res => {
        console.log(res)
      }
    })
  },
  bindPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },
  bindDateChange: function (e) {
    this.setData({
      date: e.detail.value
    })
  },
  bindTimeChange: function (e) {
    this.setData({
      time: e.detail.value
    })
  },
  onLoad(option) {
    if (option && option.obj) {
      const obj = JSON.parse(option.obj);
      this.setData({
        info: obj
      })
    }
  },
  increment: function (event) {
    console.log(event)
    testCollection.doc(info._id).update({
      data:{
        item_numofpro:_.inc(1)
      }
    })

  },


 tijiao: function (e) {

    wx.showToast({
      title: '提交成功',
      icon: 'success',
      duration: 1500,
      mask: true
    })
  }



})