var myData = require("../../utils/data")
import {
  insert
} from '../../utils/util'
Page({
  data: {
    // province: myData.provinceData(),
    // city: myData.cityData(),
    tag: myData.getIndexNavData().map(item=>item.title).filter(item=>item!='推荐'),
    // proviIndex: 0,
    // cityIndex: 0,
    tagIndex: 0,
    // saveToastHidden: true,
    item_name: "",
    item_detail: "",
    item_prove: "",
    item_var: "",
    item_owner: "",
    item_donne: "",
    imgList: [],
    item_image: null
  },
  onLoad: function(options) {
    // var init = myData.searchAddrFromAddrs(options.addrid)
    // this.setData({
    //   data_name: init.name,
    //   data_phone: init.phone,
    //   data_province: init.province,
    //   data_city: init.city,
    //   data_addr: init.addr,
    //   data_tag: init.tag
    // })
  },
  // // 省份选择
  // bindProviPickerChange: function(e) {
  //   console.log('province  picker发送选择改变，携带值为', e.detail.value)
  //   this.setData({
  //     proviIndex: e.detail.value
  //   })
  // },
  // // 城市选择
  // bindCityPickerChange: function(e) {
  //   console.log('city  picker发送选择改变，携带值为', e.detail.value)
  //   this.setData({
  //     cityIndex: e.detail.value
  //   })
  // },
  // 项目类型选择
  bindTagPickerChange: function(e) {
    console.log('tag  picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      tagIndex: e.detail.value
    })
  },
  ChooseImage() {
    const that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album'],
      success: (res) => {
        if (res.tempFiles[0].size > 5 * 1024 * 1024) {
          wx.showModal({
            title: '提示',
            content: '图片大小不能超过5M',
            showCancel: false
          })
          return
        }
        wx.showLoading({
          title: '上传中',
        })
        //微信自带API上传图片到后台
        wx.uploadFile({
          url: "http://114.55.102.116:28184/comm/uploadImg",
          filePath: res.tempFilePaths[0],
          name: 'file',
          success: function(res) {
            res = JSON.parse(res.data)
            if (res.status == 200) {
              that.setData({
                imgList: ["https://ohp.oss-cn-beijing.aliyuncs.com/" + res.result.fileName],
                item_image: "https://ohp.oss-cn-beijing.aliyuncs.com/" + res.result.fileName
              })
            } else {
              wx.showToast({
                title: '图片上传失败',
                icon: 'none',
                duration: 1500
              })
            }
          },
          fail: function(res) {
            console.log(res);
            wx.showToast({
              title: '图片上传失败',
              icon: 'none',
              duration: 1500
            })
          },
          complete: function(res) {
            wx.hideLoading()
          }
        })
        // wx.getFileSystemManager().readFile({
        //   filePath: res.tempFilePaths[0],
        //   encoding: 'base64',
        //   success: res => {
        //     that.setData({
        //       imgList: ['data:image/png;base64,' + res.data],
        //       item_image: 'data:image/png;base64,' + res.data
        //     })
        //   }
        // })
      }
    });
  },
  ViewImage(e) {
    wx.previewImage({
      urls: this.data.imgList,
      current: e.currentTarget.dataset.url
    });
  },
  DelImg(e) {
    wx.showModal({
      title: '图片删除',
      content: '确定要删除图片吗？',
      cancelText: '取消',
      confirmText: '确认',
      success: res => {
        if (res.confirm) {
          this.data.imgList.splice(e.currentTarget.dataset.index, 1);
          this.setData({
            imgList: this.data.imgList,
            item_image: null
          })
        }
      }
    })
  },
  inputedit(e) {
    let dataset = e.currentTarget.dataset;
    let value = e.detail.value;
    this.data[dataset.obj] = value;
  },
  submitForm: function(e) {
    const data = e.detail.value
    data.item_detail = this.data.item_detail
    data.item_image = this.data.item_image
    data.item_var = myData.item_var_data[data.item_var]
    if (this.isEmpty(data.item_owner)) {
      wx.showModal({
        title: '提示',
        content: '请填写发起人姓名',
        showCancel: false
      })
      return
    }
    if (this.isEmpty(data.item_name)) {
      wx.showModal({
        title: '提示',
        content: '请填写项目名称',
        showCancel: false
      })
      return
    }
    if (this.isEmpty(data.item_var)) {
      wx.showModal({
        title: '提示',
        content: '请选择项目类型',
        showCancel: false
      })
      return
    }
    if (this.isEmpty(data.item_donee)) {
      wx.showModal({
        title: '提示',
        content: '请填写受助人姓名',
        showCancel: false
      })
      return
    }
    if (this.isEmpty(data.item_image)) {
      wx.showModal({
        title: '提示',
        content: '请上传图片',
        showCancel: false
      })
      return
    }
    insert(data).then(res => {
      wx.hideLoading()
      wx.showToast({
        title: '发起成功',
        icon: 'success',
        duration: 2000,
        success() {
          wx.switchTab({
            url: '/pages/index/index',
          })
        }
      })
    }).catch(err => {
      wx.hideLoading()
      wx.showModal({
        title: '失败',
        content: err,
        showCancel: false
      })
    })

    // setTimeout(() => {

    // }, 2500)
  },
  hideToast: function() {

    this.setData({
      saveToastHidden: true
    })
  },
  isEmpty(value) {
    return typeof value === 'undefined' || value === null ||
      value === undefined || value == [] || value === '' || this.isEmptyObject(value);
  },
  isEmptyObject(obj) {
    for (var key in obj) {
      return false;
    }
    return true;
  }

})