//details.js
const db=wx.cloud.database()
const testCollection=db.collection('test')

Page({
  data:{
    ratio:0
  },
  onLoad: function (options) {
    testCollection.where({
      _id: "f4b905395cecf73407140cf56d37f458"
    }).get().then(res => {
      console.log(res.data)
      this.setData({
        item: res.data
      })
      let ratio= 100 * res.data[0].item_gain / res.data[0].item_target

      console.log(ratio)
      this.setData({
        ratio:ratio
      })
    })
  },

})