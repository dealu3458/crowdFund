// pages/myfollow/myfollow.js
var app = getApp()
var fileData = require('../../utils/data.js')
import {
  select
} from '../../utils/util'

Page({
  data: {
    templateMessageResult: '',
    wxacodeSrc: '',
    wxacodeResult: '',
    showClearWXACodeCache: false,
    colors: ['red', 'orange', 'yellow', 'green', 'purple'],
    // banner 初始化
    banner_url: fileData.getBannerData(),
    indicatorDots: true,
    vertical: false,
    autoplay: true,
    interval: 3000,
    duration: 1000,
    // nav 初始化
    navTopItems: fileData.getIndexNavData(),
    navSectionItems: fileData.getIndexNavSectionData(),
    curNavId: '推荐',
    curIndex: 0,
    list: [],
    originList: []
  },

  selectPage(index) {
    const that = this
    select(index).then(res => {
      wx.hideLoading()
      that.setData({
        list: res.data,
        originList: res.data,
        curIndex: that.data.curIndex + 1
      })
    })
  },
  onLoad: function () {
    // that.setData({
    //   list: that.data.navSectionItems
    // })
  },
  onShow() {
    var that = this
    that.selectPage(0)
  },
  //标签切换
  switchTab: function (e) {
    let id = e.currentTarget.dataset.id
    const that = this;
    that.setData({
      list: that.data.originList.filter(item => {
        if (id == '推荐')
          return true;
        else
          return item.item_var == id;
      }),
      curNavId: id
    })

  },
  // 跳转至详情页
  navigateDetail: function (e) {
    var obj = this.data.list.filter(item => item._id == e.currentTarget.dataset.aid)[0]
    wx.navigateTo({
      url: '../details/details?obj=' + JSON.stringify(obj)
    })
  },
  // 加载更多
  loadMore: function (e) {
    console.log('加载更多')
    var curid = this.data.curIndex
    that.selectPage(curid)
    // if (this.data.navSectionItems[curid].length === 0) return

    // var that = this
    // that.data.navSectionItems[curid] = that.data.navSectionItems[curid].concat(that.data.navSectionItems[curid])
    // that.setData({
    //   list: that.data.navSectionItems,
    // })
  },
  // book
  bookTap: function (e) {
    wx.navigateTo({
      url: '../donation/donation?aid=' + e.currentTarget.dataset.aid
    })
  },

  submitTemplateMessageForm(e) {
    this.setData({
      templateMessageResult: '',
    })

    wx.cloud.callFunction({
      name: 'openapi',
      data: {
        action: 'sendTemplateMessage',
        formId: e.detail.formId,
      },
      success: res => {
        console.warn('[云函数] [openapi] templateMessage.send 调用成功：', res)
        wx.showModal({
          title: '发送成功',
          content: '请返回微信主界面查看',
          showCancel: false,
        })
        wx.showToast({
          title: '发送成功，请返回微信主界面查看',
        })
        this.setData({
          templateMessageResult: JSON.stringify(res.result)
        })
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '调用失败',
        })
        console.error('[云函数] [openapi] templateMessage.send 调用失败：', err)
      }
    })
  },

  onGetWXACode() {

    this.setData({
      wxacodeSrc: '',
      wxacodeResult: '',
      showClearWXACodeCache: false,
    })

    // 此处为演示，将使用 localStorage 缓存，正常开发中文件 ID 应存在数据库中
    const fileID = wx.getStorageSync('wxacodeCloudID')

    if (fileID) {
      // 有云文件 ID 缓存，直接使用该 ID
      // 如需清除缓存，选择菜单栏中的 “工具 -> 清除缓存 -> 清除数据缓存”，或在 Storage 面板中删掉相应的 key
      this.setData({
        wxacodeSrc: fileID,
        wxacodeResult: `从本地缓存中取得了小程序码的云文件 ID`,
        showClearWXACodeCache: true,
      })
      console.log(`从本地缓存中取得了小程序码的云文件 ID：${fileID}`)
    } else {
      wx.cloud.callFunction({
        name: 'openapi',
        data: {
          action: 'getWXACode',
        },
        success: res => {
          console.warn('[云函数] [openapi] wxacode.get 调用成功：', res)
          wx.showToast({
            title: '调用成功',
          })
          this.setData({
            wxacodeSrc: res.result,
            wxacodeResult: `云函数获取二维码成功`,
            showClearWXACodeCache: true,
          })
          wx.setStorageSync('wxacodeCloudID', res.result)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '调用失败',
          })
          console.error('[云函数] [openapi] wxacode.get 调用失败：', err)
        }
      })
    }
  },

  clearWXACodeCache() {
    wx.removeStorageSync('wxacodeCloudID')

    this.setData({
      wxacodeSrc: '',
      wxacodeResult: '',
      showClearWXACodeCache: false,
    })

    wx.showToast({
      title: '清除成功',
    })
  },

})
