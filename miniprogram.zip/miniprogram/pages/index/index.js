//index.js
//获取应用实例
var app = getApp()
var fileData = require('../../utils/data.js')
import {
  select
} from '../../utils/util'
Page({
  // 页面初始数据
  data: {
    colors: ['red', 'orange', 'yellow', 'green', 'purple'],
    // banner 初始化
    banner_url: fileData.getBannerData(),
    indicatorDots: true,
    vertical: false,
    autoplay: true,
    interval: 3000,
    duration: 1000,
    // nav 初始化
    navTopItems: fileData.getIndexNavData(),
    navSectionItems: fileData.getIndexNavSectionData(),
    curNavId: '推荐',
    curIndex: 0,
    list: [],
    originList: []
  },
  selectPage(index) {
    const that = this
    select(index).then(res => {
      wx.hideLoading()
      that.setData({
        list: res.data,
        originList: res.data,
        curIndex: that.data.curIndex + 1
      })
    })
  },
  onLoad: function() {
    // that.setData({
    //   list: that.data.navSectionItems
    // })
  },
  onShow() {
    var that = this
    that.selectPage(0)
  },
  //标签切换
  switchTab: function(e) {
    let id = e.currentTarget.dataset.id
    const that = this;
    that.setData({
      list: that.data.originList.filter(item => {
        if (id =='推荐')
          return true;
        else
          return item.item_var == id;
      }),
      curNavId: id
    })

  },
  // 跳转至详情页
  navigateDetail: function(e) {
    var obj = this.data.list.filter(item => item._id == e.currentTarget.dataset.aid)[0]
    wx.navigateTo({
      url: '../details/details?obj=' + JSON.stringify(obj)
    })
  },
  // 加载更多
  loadMore: function(e) {
    console.log('加载更多')
    var curid = this.data.curIndex
    that.selectPage(curid)
    // if (this.data.navSectionItems[curid].length === 0) return

    // var that = this
    // that.data.navSectionItems[curid] = that.data.navSectionItems[curid].concat(that.data.navSectionItems[curid])
    // that.setData({
    //   list: that.data.navSectionItems,
    // })
  },
  // book
  bookTap: function(e) {
    wx.navigateTo({
      url: '../donation/donation?aid=' + e.currentTarget.dataset.aid
    })
  }

})