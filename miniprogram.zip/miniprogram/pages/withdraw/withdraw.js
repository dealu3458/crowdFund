Page({
  data:{
    content:'输入金额（元）',
    money_donate:0,
    item:'item'
  },
  setValue1:function(e){
    this.setData({
      content:'5',
      money_donate:5
    })
  },
  setValue2: function (e) {
    this.setData({
      content: '20',
      money_donate:20
    })
  },
  setValue3: function (e) {
    this.setData({
      content: '100',
      money_donate:100
    })
  },
  getMoney:function(e){
    this.setData({
      money_donate:e.detail.value,
      content:0
    })
  },
  zhifu:function(e){
    
    wx.showToast({
      title: '支付功能未开通\n敬请期待',
      icon: 'loading',
      duration: 3000,
      mask: true
    }),
    wx.requestPayment({
      'timeStamp': '',
      'nonceStr': '',
      'package': '',
      'signType': 'MD5',
      'paySign': '',
      'success': function (res) { },
      'fail': function (res) { },
      'complete': function (res) { }
    })
  }
  
})