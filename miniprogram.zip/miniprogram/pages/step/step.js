// pages/step/step.js

Page({

  /**
   * 页面的初始数据
   */
  data: {
    //后端应该接入个人数据库，包含weRunStep，并每日清零、更新
    //wx.getWeRunData也没有搞定 sigh...
    weRunStep: 3992,
    coupon: 0,
    helpDetail: "1. 走路行善是EasyFunding小程序功能，可以通过行走兑换爱心券，并免费赠送给患者，患者可使用爱心券兑换补贴现金\n\n2. 爱心券是EasyFunding平台的虚拟券。用户可以用来帮助大病筹款项目\n\n3. 爱心券仅限本人帮助患者使用，不可提现和转让\n\n4. 有关爱心券任何说明，以EasyFunding平台发布内容为准，EasyFunding拥有最终解释权"
  },
      
        /**
         * 生命周期函数--监听页面加载
         */
  onLoad: function (options) {
    /**
    wx.cloud.callFunction({
      name: "login",
      data: {

      }
    })
    wx.getWeRunData({
      success(res) {
        const cloudID = res.cloudID
      }
    })
    wx.cloud.callFunction({
      name: "decryptStep",
      data: {
        weRunData: wx.cloud.CloudID(cloudID)
       }
    })
    */
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    /**
     * 检查、请求微信运动权限
     */
    wx.getSetting({
      success(res) {
        if (!res.authSetting['scope.werun']) {
          wx.authorize({
            scope: 'scope.werun',
            success() {
              // 用户已经同意小程序使用运动功能，后续调用接口不会弹窗询问
              wx.getWeRunData()
            }
          })
        }
      }
    })
  },



  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },


  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  /**
   * 用户点击兑换爱心券
   */
  stepExchange: function () {
    var newCoupon = 0
    var stepNumber = this.data.weRunStep
    var couponNumber = this.data.coupon
    //步数不足2000，兑换失败
    if(stepNumber < 2000) {
      console.log("步数不足")
      wx.showToast({title: "步数不足2000，无法兑换", icon: "none", duration: 2000})
    }
    //兑换成功
    else {
      newCoupon = Math.trunc(stepNumber/2000)
      stepNumber = stepNumber - newCoupon*2000
      //this.data.weRunStep = stepNumber
      couponNumber = couponNumber + newCoupon
      //this.data.coupon = couponNumber
      this.setData({weRunStep: stepNumber, coupon: couponNumber})
      wx.showToast({title: "步数兑换成功", icon: "success", duration: 2000})
      this.onLoad()
    }
    //console.log(this.data.weRunStep)
    //console.log(this.data.coupon)
  },


  /**
   * 生命周期函数--监听页面卸载
   
  onLoad: function () {
    const self = this;
    wx.login({
      success: function (res) {
        if (res.code) {
          wx.request({
            url: "https://www.xxx.com.cn/api/auth/login",
            method: 'POST',
            data: {
              code: res.code
            },
            success: function (res) {
              app.globalData.userInfo.token = res.data.token;
              app.globalData.userInfo.session_key = res.data.session_key;
              self.getWeRunData();
            }
          })
        }
      }
    });
  },

    /**
   * getWeRunData: function () {
    wx.getSetting({
      success: function (res) {
        if (res.authSetting['scope.werun'] === false) {
          wx.showModal({
            title: '提示',
            content: '请开启获取微信步数权限',
            showCancel: false,
            confirmText: '知道了'
          })
        } else {
          wx.authorize({
            scope: 'scope.werun',
            success() {
              wx.getWeRunData({
                success: function (res) {
                  wx.request({
                    url: "https://www.xxx.com.cn/api/getWeRunData",
                    method: 'POST',
                    header: {
                      "accept": "application/json",
                      "Authorization": app.globalData.userInfo.token
                    },
                    data: {
                      encryptedData: res.encryptedData,
                      iv: res.iv,
                      session_key: app.globalData.userInfo.session_key
                    },
                    success: function (res) {
                      console.log("步数：" + res.data.data.steps);
                      wx.showModal({
                        title: '步数',
                        content: res.data.data.steps + '',
                      })
                    }
                  })
                },
                fail: function (res) {
                  wx.showModal({
                    title: '提示',
                    content: '请先关注“微信运动”公众号并设置数据来源，以获取并提供微信步数数据',
                    showCancel: false,
                    confirmText: '知道了'
                  })
                }
              })
            },
            fail() {
              wx.showModal({
                title: '提示',
                content: '请开启获取微信步数权限',
                showCancel: false,
                confirmText: '知道了'
              })
            }
          })
        }
      }
    })
  }
  */

})