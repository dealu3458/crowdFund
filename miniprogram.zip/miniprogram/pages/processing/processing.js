// miniprogram/pages/processing.js
const app = getApp()
const db = wx.cloud.database()
const testCollection = db.collection('project')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    //应该通过数据库获取这个审核中项目的各种信息，如下...
    projectID: 100000,
    name: "张晓明",
    phone: "123456",
    targetMoney: 10000,
    tag: "大病救助",
    intro: "请帮助我！",
    //0代表未通过，1代表已通过，2代表正在审核，3代表已删除
    status: 2
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    testCollection.where({
      _id: "57896b495cef6bec081f332a3776d516"
    }).get().then(res => {
      console.log(res.data)
      this.setData({
        projects: res.data
      })
    })
    this.setData({name: projects[0].item_donee, phone: projects[0].item_phone, targetMoney: projects[0].item_target, tag: projects[0].item_var, intro: projects[0].item_detail})
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function (options) {
    testCollection.where({
      item_donee: app.glo
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  /**
   * 用户点击按钮删除申请
   */
  deleteApplication: function () {
    //需要接入云函数和数据库！
    if (status == 2) {
      this.setData({ status: 3 })
      wx.showToast({ title: "申请取消成功", icon: "success", duration: 2000 })
      this.onLoad()
      //待补充
    }
    else {
      console.log("项目状态不是正在审核中！有错!")
    }
  }
})