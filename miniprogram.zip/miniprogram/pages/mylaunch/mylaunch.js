// pages/mylaunch/mylaunch.js
const db = wx.cloud.database()
const testCollection = db.collection('project') 
const app=getApp()
Page({

  data: {
    templateMessageResult: '',
    wxacodeSrc: '',
    wxacodeResult: '',
    showClearWXACodeCache: false,
    //应该通过数据库获取这个审核中项目的各种信息，如下...
    projectID: 100000,
    name: "张晓明",
    phone: "18345151691",
    targetMoney: 10000,
    tag: "大病救助",
    intro: "希望大家帮帮我！",
    //0代表未通过，1代表已通过，2代表正在审核，3代表已删除
    status: 2
  },

 
  moveToProcessing: function (){
    wx.navigateTo({url: "pages/processing/processing"})//有问题！！！
  },

  onLoad: function (options) {
    testCollection.where({
      _id: "57896b495cef6bec081f332a3776d516"
    }).get().then(res => {
      console.log(res.data)
      this.setData({
        projects: res.data
      })
    })
    this.setData({name: projects[0].item_donee, phone: projects[0].item_phone, targetMoney: projects[0].item_target, tag: projects[0].item_var, intro: projects[0].item_detail})
  }
})
